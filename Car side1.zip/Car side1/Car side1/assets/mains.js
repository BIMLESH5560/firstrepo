// ---------=========nav code start=========-------------

$(document).ready(function() {
    var touch = $('#resp-menu');
    var menu = $('.menu');

    $(touch).on('click', function(e) {
        e.preventDefault();
        menu.slideToggle();
    });

    $(window).resize(function() {
        var w = $(window).width();
        if (w > 767 && menu.is(':hidden')) {
            menu.removeAttr('style');
        }
    });

});

// ---------=========nav code end=========-------------

// ------------=============slider code  start===========-----------

let slideIndex = 0;
showSlides();

function showSlides() {
    let i;
    let slides = document.getElementsByClassName("mySlides");
    let dots = document.getElementsByClassName("dot");
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }
    slideIndex++;
    if (slideIndex > slides.length) {
        slideIndex = 1;
    }
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[slideIndex - 1].style.display = "block";
    dots[slideIndex - 1].className += " active";
    setTimeout(showSlides, 3000); // 3000 = Change image every 3 seconds
}


// ------------=============slider code  end===========-----------

// ---------=-=========tab slider code start=========-----------

// $(document).ready(function() {
//     $('.your-class').slick({
//         infinite: true,
//         slidesToShow: 4,
//         slidesToScroll: 4
//     });
// });

// $('a[data-toggle="tab"]').on('shown.bs.tab', function(e) {
//         $('.your-class').slick('setPosition');
//     })


$('.responsive').slick({
    dots: true,
    infinite: false,
    speed: 300,
    slidesToShow: 4,
    slidesToScroll: 4,
    responsive: [{
            breakpoint: 1024,
            settings: {
                slidesToShow: 3,
                slidesToScroll: 3,
                infinite: true,
                dots: true
            }
        },
        {
            breakpoint: 600,
            settings: {
                slidesToShow: 2,
                slidesToScroll: 2
            }
        },
        {
            breakpoint: 480,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1
            }
        }
        // You can unslick at a given breakpoint now by adding:
        // settings: "unslick"
        // instead of a settings object
    ]
});

// ---------=-=========tab slider code end=========-----------

function openCity(cityName) {
    var i;
    var x = document.getElementsByClassName("city");
    for (i = 0; i < x.length; i++) {
        x[i].style.display = "none";
    }
    document.getElementById(cityName).style.display = "block";
}




// ------========tabCarousel 2 code start=========-------

// Script written by @hamzadhamiya for @bloggerever.
// http://bloggerever.com

$(function() {
    $.FindContainer = function() {
        $('.tab-content>div').each(function findcontent() {
            var newindex = $('.activetab').index();
            var newheight = $('.activetab').height();
            $('.tab-content').animate({
                'height': newheight + 20
            }, 100);
            var otherindex = $(this).index();
            var substractindex = otherindex - newindex;
            var currentwidth = $('.multipletab').width();
            var newpositions = substractindex * currentwidth;
            $(this).animate({
                'left': newpositions
            });
        });
    };
    $.FindId = function() {
        $('.tab-content>div').each(function() {
            if ($(this).attr('id') == $('.active').attr('id')) {
                $('.tab-content>div').removeClass('activetab');
                $(this).addClass('activetab');
            }
        });
    };
    $('.tab-buttons>span').first().addClass('active');
    $('.tab-content>div').each(function() {
        var activeid = $('.active').attr('id');
        if ($(this).attr('id') == activeid) {
            $(this).addClass('activetab');
        }
        var currentheight = $('.activetab').height();
        var currentwidth = $('.multipletab').width();
        var currentindex = $(this).index();
        var currentposition = currentindex * currentwidth;
        $(this).css({
            'left': currentposition,
            'width': currentwidth - 40,
            'padding': '10px 20px'
        });
        $(this).attr('data-position', currentposition);
        $('.tab-content').css('height', currentheight + 20);
    });
    $('.tab-buttons>span').click(function() {

        $('.tab-buttons>span').removeClass('active');
        $(this).addClass('active');
        var currentid = $('.active').attr('id');
        $.FindId();
        $.FindContainer();
    });
    $('.next').click(function() {
        var activetabindex = $('.activetab').index() + 1;
        var containers = $('.tab-content>div').length;
        if (containers == activetabindex) {
            $('.tab-buttons>span').removeClass('active');
            $('.tab-buttons>span').first().addClass('active');
            var currentid = $('.active').attr('id');
            $.FindId();
            $.FindContainer();
        } else {
            var currentopen = $('.active').next();
            $('.active').removeClass('active');
            currentopen.addClass('active');
            $.FindId();
            $.FindContainer();
        }
    });
    $('.prev').click(function() {
        var activetabindex = $('.activetab').index();
        if (activetabindex == 0) {
            $('.tab-buttons>span').removeClass('active');
            $('.tab-buttons>span').last().addClass('active');
            var currentid = $('.active').attr('id');
            $.FindId();
            $.FindContainer();
        } else {
            var currentopen = $('.active').prev();
            $('.active').removeClass('active');
            currentopen.addClass('active');
            $.FindId();
            $.FindContainer();
        }
    });
});

// ------========tabCarousel 2code end=========-------


// papular brand code start


$('.icones-carousel').slick({
    nextArrow: '<i class="fa fa-arrow-right"></i>',
    prevArrow: '<i class="fa fa-arrow-left"></i>',
    autoplay: true,
    autoplaySpeed: 2500,
    dots: false,
    arrows: true,
    infinite: true,
    speed: 500,
    cssEase: 'linear',
    slidesToShow: 4,
    slidesToScroll: 1,
    responsive: [{
        breakpoint: 700,
        settings: {
            dots: true,
            arrows: true,
            slidesToShow: 1,
            slidesToScroll: 1,
        }
    }]
});

// papular brand code end








// ------=======campair code start=======------




// ------=======campair code end=======------




(function() {
    var $carousels, $slideScrollers, $thumbnailScrollers, $nextBtns, $prevBtns;
    const activeThumbnail = 'active',
        scrollingThumbnails = 'scrolling',
        disabledBtns = 'disabled';

    $(document).ready(function() {
        $carousels = $('.carousel');
        $slideScrollers = $carousels.find('.slide-container');
        $thumbnailScrollers = $carousels.find('.thumb-container');

        $nextBtns = $carousels.find('.next').on('click', nextSlide);
        $prevBtns = $carousels.find('.prev').on('click', prevSlide);
        $slideScrollers.on('scroll', scrollHandler);

        // Set up initial state
        $carousels.each(function() {
            updateIndicators($(this));
            updateArrows($(this));
        });
    });

    function nextSlide(e) {
        e.preventDefault();
        var $carousel = $(this).closest($carousels);
        scrollToSlide($carousel, $carousel.data('currIndex') + 1);
    }

    function prevSlide(e) {
        e.preventDefault();
        var $carousel = $(this).closest($carousels);
        scrollToSlide($carousel, $carousel.data('currIndex') - 1);
    }

    function scrollHandler() {
        var $carousel = $(this).closest($carousels);
        updateIndicators($carousel);
        updateArrows($carousel);
    }

    function scrollToSlide($carousel, index) {
        var $container = $carousel.find($slideScrollers);
        var $slides = $container.find('li');
        var goToIndex = Math.max(Math.min(index, $slides.length - 1), 0); // make sure the index is within the bounds of the slideshow

        if ($carousel.data('currIndex') == goToIndex) { return; } // bail - no need to update the DOM

        var scrollTo = $slides.eq(goToIndex).get(0).offsetLeft - $container.get(0).offsetLeft;
        $container.get(0).scrollTo(scrollTo, 0);
        updateIndicators($carousel, index);
        updateArrows($carousel);
    }

    function getCurrentSlide($carousel) {
        var $container = $carousel.find($slideScrollers);
        var scrollPos = $container.get(0).scrollLeft;
        var containerOffset = $container.get(0).offsetLeft;

        var $slides = $container.find('li');
        var index = 0;

        $slides.each(function(i) {
            var slidePos = this.offsetLeft - containerOffset;
            if (slidePos <= scrollPos) {
                index = i;
            } else {
                return false; // bail out, we've passed the scroll position
            }
        });

        return index;
    }

    function updateIndicators($carousel, index) {
        if (typeof index == 'undefined') {
            index = getCurrentSlide($carousel);
        }

        if ($carousel.data('currIndex') == index) { return; } // bail - no need to update the DOM

        var $indicatorScroller = $carousel.find($thumbnailScrollers);
        var $indicators = $indicatorScroller.find('li');
        var $currIndicator = $indicators.eq(index);

        $indicators.find('a').removeClass(activeThumbnail);
        $currIndicator.find('a').addClass(activeThumbnail);

        $carousel.data('currIndex', index);

        // Scroll the indicators to center the one that is active
        var indicatorPos = $currIndicator.get(0).offsetLeft - $indicatorScroller.get(0).offsetLeft;
        var scrollerWidth = $indicatorScroller.width();
        var scrollTo = -(scrollerWidth / 2) + indicatorPos + ($currIndicator.width() / 2);
        $indicatorScroller.addClass(scrollingThumbnails).animate({
            scrollLeft: scrollTo
        }, 400, function() {
            $indicatorScroller.removeClass(scrollingThumbnails);
        });
    }

    function updateArrows($carousel) {
        var $slides = $carousel.find($slideScrollers).find('li');
        var $next = $carousel.find($nextBtns);
        var $prev = $carousel.find($prevBtns);
        var currIndex = $carousel.data('currIndex');

        if (currIndex >= $slides.length - 1) {
            $next.addClass(disabledBtns);
        } else if ($next.hasClass(disabledBtns)) {
            $next.removeClass(disabledBtns);
        }

        if (currIndex <= 0) {
            $prev.addClass(disabledBtns);
        } else if ($prev.hasClass(disabledBtns)) {
            $prev.removeClass(disabledBtns);
        }
    }
})();




// contact Pop-up code start

// Get the modal
var modal = document.getElementById("myModal");

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks on the button, open the modal
btn.onclick = function() {
    modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
    modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}