<?php
$to = "hemant95pandey@gmail.com";
$subject = "My subject";
$txt = "Hello world!";
$headers = "From: Sanu893pandey@gmail.com" . "\r\n" .
"CC: somebodyelse@example.com";

mail($to,$subject,$txt,$headers);
?>

    <html lang="en">

    <head>

        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>

        <link rel="stylesheet" href="../assets/style.css">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

        <!-- <script src="https://use.fontawesome.com/5a8a7bb461.js"></script>


    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script> -->
        <style>
            .modal {
                display: none;
                /* Hidden by default */
                position: fixed;
                /* Stay in place */
                z-index: 1;
                /* Sit on top */
                left: 0;
                top: 0;
                width: 100%;
                /* Full width */
                height: 100%;
                /* Full height */
                overflow: auto;
                /* Enable scroll if needed */
                background-color: rgb(0, 0, 0);
                /* Fallback color */
                background-color: rgba(0, 0, 0, 0.4);
                /* Black w/ opacity */
            }
            /* Modal Content/Box */
            
            .modal-content {
                background-color: #efefef;
                margin: 15% auto;
                /* 15% from the top and centered */
                padding: 20px;
                border: 1px solid rgb(174, 151, 151);
                width: 30%;
                /* Could be more or less, depending on screen size */
            }
            /* The Close Button */
            
            .close {
                color: #aaa;
                float: right;
                font-size: 28px;
                font-weight: bold;
            }
            
            .close:hover,
            .close:focus {
                color: black;
                text-decoration: none;
                cursor: pointer;
            }
        </style>
    </head>

    <body>

        <!-- --------==========nav  code start==========---------  -->
        <div class="navbar">

            <!-- Navbar logo -->
            <div class="nav-header">
                <div class="nav-logo">
                    <a href="../index.html">
                        <img src="../assets/img/logo/vehica-logo.png" width="100px" alt="logo">
                    </a>
                </div>
            </div>

            <!-- responsive navbar toggle button -->
            <input type="checkbox" id="nav-check">
            <div class="nav-btn">
                <label for="nav-check">
                <span></span>
                <span></span>
                <span></span>
            </label>
            </div>

            <!-- Navbar items -->
            <div class="nav-links">
                <a href="index.html">Home</a>
                <a href="../index.html#Upcoming-all">Upcoming</a>
                <!-- Dropdown menu -->

                <a href="../index.html#Compare-sec">Compare</a>

                <!-- Dropdown menu -->
                <div class="dropdown">
                    <a class="dropBtn" href="#">Used car
                <i class="fas fa-angle-down"></i>
                </a>
                    <div class="drop-content">
                        <a href="#">Web Design</a>
                        <a href="#">Marketing</a>
                        <a href="#">WordPress</a>

                        <!-- Creating sub menu Dropdown -->
                        <div class="dropdown2">
                            <a class="dropBtn2" href="#">all co
                    <i class="fas fa-angle-right"></i>
                    </a>
                            <div class="drop-content2">
                                <a href="#">HTML</a>
                                <a href="#">CSS</a>
                                <a href="#">JavaScript</a>
                                <a href="#">jQuery</a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Dropdown menu -->

                <a href="../index.html#Latest-all">Latest</a>



                <a href="#">Blogs</a>
                <a href="#footer-det">Contact</a>
                <button class="loginBtn">Login</button>
            </div>

        </div>

        <!-- --------==========nav  code end==========---------  -->


        <!-- <div class="breadcrumb-area "></div> -->



        <!-- Place somewhere in the <body> of your page -->
        <section>
            <div class="container">
                <div class="row">

                    <div class="col-md-8 com-img">
                        <div class="Tata-hea">
                            <h4>Toyota Innova Crysta</h4>
                        </div>

                        <img src="../assets/img/Toyota-Innova-Crysta-at-2017.jpg" alt="Slide 1 Image" />

                    </div>
                    <div class="col-lg-4">
                        <div class="details-info-area">
                            <div class="heading">
                                <h4 class="title">
                                    DETAILS INFO
                                </h4>
                                <ul class="details-list">
                                    <li>
                                        <p>CATEGORY:</p>
                                        <P>Category A</P>
                                    </li>
                                    <li>
                                        <p>PRICE:</p>
                                        <p>Rs17.86 - 23.83 Lakh*</p>
                                    </li>
                                    <li>
                                        <p>NEGOTIABLE:</p>
                                        <p>NO</p>
                                    </li>
                                    <li>
                                        <p>CONDITION:</p>
                                        <p>Recondtioned</p>
                                    </li>
                                    <li>
                                        <p>TOP SPEED:</p>
                                        <p>200.00 KM/H</p>
                                    </li>
                                    <li>
                                        <p>YEAR:</p>
                                        <p>2022</p>
                                    </li>
                                    <li>
                                        <p>MILEAGE:</p>
                                        <p>18 kmpl</p>
                                    </li>
                                    <li>
                                        <p>BRAND:</p>
                                        <p>MUV</p>
                                    </li>
                                    <li>
                                        <p>MODEL:</p>
                                        <p>Other MUV Models</p>
                                    </li>
                                    <li>
                                        <p>BODY TYPE:</p>
                                        <p>MUV</p>
                                    </li>
                                    <li>
                                        <p>FUEL TYPE:</p>
                                        <p>Petrol</p>
                                    </li>
                                    <li>
                                        <p>TRANSMISSION:</p>
                                        <p>Continuously Variable</p>
                                    </li>
                                    <li>
                                        <p>Drivetrain:</p>
                                        <p>AWD</p>
                                    </li>
                                    <li>
                                        <p>Interior Color:</p>
                                        <p>Tan</p>
                                    </li>
                                    <li>
                                        <p>VIN Number:</p>
                                        <p>4JGDA5HB2CA006345</p>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <!-- <div class="latest-cars">
                                        <div class="heading">
                                            <h4 class="title">
                                                RELATED CARS
                                            </h4>
                                        </div>
                                        <ul class="cars-list">
                                            <li>
                                                <div class="landscape-single-car">
                                                    <div class="img">
                                                        <img src="../assets/front/images/cars/featured/5d67959c9ca87.jpg" alt="">
                                                    </div>
                                                    <div class="content">
                                                        <a href="7.html" class="d-block">
                                                            <h4 class="name">
                
                                                                2012 MERCEDES-BENZ M-CLASS
                
                                                            </h4>
                                                        </a>
                                                        <p class="views">
                                                            Views: 893
                                                        </p>
                                                    </div>
                                                </div>
                                            </li>
                                        </ul>
                                    </div> -->
                    </div>
                </div>
            </div>





        </section>


        <!-- Place somewhere in the <body> of your page -->
        <section>
            <div class="container">
                <div class="row">

                    <div class="col-md-8 com-img">
                        <div class="Tata-hea">
                            <h4>MG Gloster</h4>
                        </div>
                        <img src="../assets/img/20201104051048_MG-Gloster.jpg" alt="Slide 1 Image" />

                    </div>
                    <div class="col-lg-4">
                        <div class="details-info-area">
                            <div class="heading">
                                <h4 class="title">
                                    DETAILS INFO
                                </h4>
                                <ul class="details-list">
                                    <li>
                                        <p>CATEGORY:</p>
                                        <P>Category A</P>
                                    </li>
                                    <li>
                                        <p>PRICE:</p>
                                        <p>Rs31.99 - 40.78 Lakh*</p>
                                    </li>
                                    <li>
                                        <p>NEGOTIABLE:</p>
                                        <p>NO</p>
                                    </li>
                                    <li>
                                        <p>CONDITION:</p>
                                        <p>Recondtioned</p>
                                    </li>
                                    <li>
                                        <p>TOP SPEED:</p>
                                        <p>200.00 KM/H</p>

                                    </li>
                                    <li>
                                        <p>YEAR:</p>
                                        <p>2022</p>
                                    </li>
                                    <li>
                                        <p>MILEAGE:</p>
                                        <p>13.27 kmpl</p>
                                    </li>
                                    <li>
                                        <p>BRAND:</p>
                                        <p>Sport Utility Vehicle</p>
                                    </li>
                                    <li>
                                        <p>MODEL:</p>
                                        <p>Other SUV Models</p>
                                    </li>
                                    <li>
                                        <p>BODY TYPE:</p>
                                        <p> SUV</p>
                                    </li>
                                    <li>
                                        <p>FUEL TYPE:</p>
                                        <p> Diesel</p>


                                    </li>
                                    <li>
                                        <p>TRANSMISSION:</p>
                                        <p>Continuously Variable</p>
                                    </li>
                                    <li>
                                        <p>Drivetrain:</p>
                                        <p>AWD</p>
                                    </li>
                                    <li>
                                        <p>Interior Color:</p>
                                        <p>Tan</p>
                                    </li>
                                    <li>
                                        <p>VIN Number:</p>
                                        <p>4JGDA5HB2CA006345</p>
                                    </li>
                                </ul>
                            </div>
                        </div>

                    </div>

                </div>
            </div>





        </section>








        <section>
            <div class="container">
                <div class="row">
                    <!-- Single Details Area End -->
                    <!--Trigger-->
                    <!-- Trigger/Open The Modal -->
                    <div class="Contact-butt">
                        <button id="myBtn">ContactUs</button>
                    </div>

                    <!-- The Modal -->
                    <div id="myModal" class="modal">

                        <!-- Modal content -->
                        <div class="modal-content">
                            <span class="close">&times;</span>
                            <!-- <p>Some text in the Modal..</p> -->

                            <form action="control-message ">

                                <div class="form21">
                                    <p>Your Name</p>
                                    <input type="text" class="form-control" name="name" placeholder="">

                                </div>

                                <div class="form21">
                                    <p>Phone Number</p>
                                    <input type="Number" class="form-control " name="Number" placeholder="">

                                </div>

                                <div class="form21">
                                    <p>Your email</p>
                                    <input type="Your email" class="form-control " name="email" placeholder="">
                                </div>


                                <div class="form21">
                                    <p>Your message (optional)</p>
                                    <textarea placeholder="" name="message" class="form-control "></textarea>


                                    <div class="form2123">
                                        <a href="#" class="">Submit</a>
                                    </div>

                            </form>

                            </div>

                        </div>
                    </div>
                </div>
        </section>



        <!-- ----------==========footer code start========----------- -->

        <section class="footer-col" id="footer-det">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <div class="footer-hea1">
                            <h1>Connect info</h1>
                        </div>
                        <div class="footer-hea2 footifdh">
                            <ul>
                                <li><a href="#"> B82 , birla colony , near Durga mandir, phulwarisharif, Delhi- 801505</a></li>
                                <li><a href="#">B-8 3rd floor sector -2 Noida near sector 15, metro station 201301</a></li>
                                <li><a href="#">info@cardekho.com</a></li>
                                <li><a href="#"> +91-9846464656</a></li>
                            </ul>

                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="footer-hea1">
                            <h1>Quick link</h1>
                        </div>
                        <div class="footer-hea2 fgff">
                            <ul>
                                <li><a href="index.html">Home</a></li>
                                <li><a href="Service.html">Service</a></li>
                                <li><a href="AboutUs.html">About</a></li>
                                <li><a href="Gallery.html">New car</a></li>
                                <li><a href="hospital.html">Used car</a></li>
                                <li><a href="ContactUs.html">ContactUs</a></li>
                            </ul>

                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="footer-hea1">
                            <h1>Connect with us</h1>
                        </div>
                        <div class="footer-hea2 fgff">
                            <ul>
                                <li> <a href="#"><i class="fa-brands fa-facebook dfdf"> </i>&nbsp;&nbsp;&nbsp;&nbsp;Facebook</a></li>
                                <li> <a href="#"><i class="fa-brands fa-instagram"></i>&nbsp;&nbsp;&nbsp;&nbsp; Instagram</a></li>
                                <li><a href="#"><i class="fa-brands fa-twitter"></i>&nbsp;&nbsp;&nbsp;&nbsp; Twitter</a></li>
                                <li><a href="#"><i class="fa-brands fa-youtube"></i>&nbsp;&nbsp;&nbsp;&nbsp; Youtube</a></li>
                            </ul>

                        </div>
                    </div>


                </div>

            </div>
        </section>

        <section class="footer-copy1">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="footer-copy ">
                            <p><i class="fa-solid fa-copyright"></i> 2022 Create By <a target="blank" href="https://webultrasolution.com/">webultrasolution</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        <script>
            var modal = document.getElementById("myModal");

            // Get the button that opens the modal
            var btn = document.getElementById("myBtn");

            // Get the <span> element that closes the modal
            var span = document.getElementsByClassName("close")[0];

            // When the user clicks on the button, open the modal
            btn.onclick = function() {
                modal.style.display = "block";
            }

            // When the user clicks on <span> (x), close the modal
            span.onclick = function() {
                modal.style.display = "none";
            }

            // When the user clicks anywhere outside of the modal, close it
            window.onclick = function(event) {
                if (event.target == modal) {
                    modal.style.display = "none";
                }
            }
        </script>
        <script src="https://npmcdn.com/flickity@2/dist/flickity.pkgd.js"></script>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js"></script>
        <script src="../assets/mains.js"></script>



    </body>

    </html>